MONGO_URI = "mongodb+srv://Akshayofficial:islandbot1904@tgbotproject.uwaxq.mongodb.net/Tgbotproject?retryWrites=true&w=majority"
API_ID = "6526942"
API_HASH = "3e0e31273667bfe888b1d140024aabdb"
BOT_TOKEN = "7882763921:AAFgi6VZWbCNDK8A2XA5YodN-ljAKMeOHAI"